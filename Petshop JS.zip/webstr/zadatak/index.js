const dataArray = [
  {
    id: 1,
    name: "Njemački pas",
    price: "2000Kn",
    imgSrc: "./images/pas.jpeg",
    age: "7",
    sex: "M",
    breed: "Stafford",
    vacinated: true,
  },
  {
    id: 2,
    name: "Bengalska macka",
    price: "3000Kn",
    imgSrc: "./images/macka.jpeg",
    age: "7",
    sex: "M",
    breed: "Bengal",
    vacinated: true,
  },
  {
    id: 3,
    name: "Minijaturni zec",
    price: "450Kn",
    imgSrc: "./images/zec.jpeg",
    age: "7",
    sex: "M",
    breed: "Miniature",
    vacinated: true,
  },
  {
    id: 4,
    name: "Zlatna ribica",
    price: "150Kn",
    imgSrc: "./images/riba.jpeg",
    age: "7",
    sex: "M",
    breed: "Goldfish",
    vacinated: false,
  },
  {
    id: 5,
    name: "Papiga",
    price: "200Kn",
    imgSrc: "./images/papiga.jpeg",
    age: "7",
    sex: "M",
    breed: "Tropical",
    vacinated: true,
  },
  {
    id: 6,
    name: "Tropska zmija",
    price: "750Kn",
    imgSrc: "./images/zmija.jpeg",
    age: "7",
    sex: "M",
    breed: "Unknown",
    vacinated: false,
  },
];

const cardContainer = document.querySelector(".card-container");
const modal = document.querySelector(".modal");
const modalTitle = document.querySelector(".modal-title");
const modalContent = document.querySelector(".modal-content");
const modalClose = document.querySelector(".modal-close");

function createModal(animalObject) {
  let modalText = document.createTextNode(animalObject.name);
  modalTitle.appendChild(modalText);
  let img = document.createElement("img");
  img.src = animalObject.imgSrc;
  let nameParagraph = document.createElement("p");
  let priceParagraph = document.createElement("p");
  let ageParagraph = document.createElement("p");
  let sexParagraph = document.createElement("p");
  let breedParagraph = document.createElement("p");
  let vacinatedParagraph = document.createElement("p");
  let nameText = document.createTextNode(`Ime: ${animalObject.name}`);
  let priceText = document.createTextNode(`Cijena: ${animalObject.price}`);
  let ageText = document.createTextNode(`Godina: ${animalObject.age}`);
  let sexText = document.createTextNode(
    `Spol: ${animalObject.sex === "M" ? "Muško" : "Žensko"}`
  );
  let breedText = document.createTextNode(`Vrsta: ${animalObject.breed}`);
  let isVacinated = document.createTextNode(
    animalObject.vacinated ? "Cijepljen" : "Nije cijepljen"
  );
  nameParagraph.appendChild(nameText);
  priceParagraph.appendChild(priceText);
  ageParagraph.appendChild(ageText);
  sexParagraph.appendChild(sexText);
  breedParagraph.appendChild(breedText);
  vacinatedParagraph.appendChild(isVacinated);
  modalContent.appendChild(img);
  modalContent.appendChild(nameParagraph);
  modalContent.appendChild(priceParagraph);
  modalContent.appendChild(ageParagraph);
  modalContent.appendChild(sexParagraph);
  modalContent.appendChild(breedParagraph);
  modalContent.appendChild(vacinatedParagraph);
  modalContent;
}

function handleModalOpen(id) {
  modal.style.visibility = "visible";
  const selectedAnimal = dataArray.find((animal) => animal.id === id);
  createModal(selectedAnimal);
  console.log("modal.style.visibility:", modal.style.visibility);
}
function handleModalClose() {
  modal.style.visibility = "hidden";
  modalTitle.replaceChildren();
  modalContent.replaceChildren();
  console.log("modal.style.visibility:", modal.style.visibility);
}

modalClose.onclick = handleModalClose;

function createCardElement(src, name, price, id) {
  let div = document.createElement("div");
  div.classList.add("card");
  div.onclick = function (event) {
    event.stopPropagation();
    handleModalOpen(id);
  };
  let img = document.createElement("img");
  img.src = src;
  let nameParagraph = document.createElement("p");
  let priceParagraph = document.createElement("p");
  let nameText = document.createTextNode(name);
  let priceText = document.createTextNode(price);
  nameParagraph.appendChild(nameText);
  priceParagraph.appendChild(priceText);
  div.appendChild(img);
  div.appendChild(nameParagraph);
  div.appendChild(priceParagraph);
  return div;
}

dataArray.forEach((object) => {
  cardContainer.appendChild(
    createCardElement(object.imgSrc, object.name, object.price, object.id)
  );
});

document.addEventListener(
  "click",
  function (event) {
    if (
      event.target.matches(".modal.close") ||
      !event.target.closest(".modal")
    ) {
      handleModalClose();
    }
  },
  false
);
